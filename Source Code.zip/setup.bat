:: Copyright (c) 2026 forXsis
:: Licensed under the MIT License.

@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
title Termulin Setup

echo === Termulin Setup ===
echo.

set "PWSH_PATH="
set "ACTION=Install.ps1"

if /i "%~1"=="-Uninstall" set "ACTION=Uninstall.ps1"

if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" (
    set "PWSH_PATH=%ProgramFiles%\PowerShell\7\pwsh.exe"
    goto :found
)

for /f "delims=" %%i in ('powershell -NoProfile -Command "$app = Get-AppxPackage -Name 'Microsoft.PowerShell'; if ($app) { Join-Path $app.InstallLocation 'pwsh.exe' }"') do (
    set "PWSH_PATH=%%i"
)
if not "!PWSH_PATH!"=="" goto :found

for /f "delims=" %%i in ('pwsh -NoProfile -Command "(Get-Process -Id $PID).Path" 2^>nul') do (
    set "PWSH_PATH=%%i"
)
if not "!PWSH_PATH!"=="" goto :found

if /i "!ACTION!"=="Install.ps1" (
    echo [INFO] PowerShell 7 не найден. Попытка установки...
    winget install --id Microsoft.PowerShell -e --accept-source-agreements --accept-package-agreements
    
    if exist "%ProgramFiles%\PowerShell\7\pwsh.exe" (
        set "PWSH_PATH=%ProgramFiles%\PowerShell\7\pwsh.exe"
        goto :found
    )
    for /f "delims=" %%i in ('powershell -NoProfile -Command "$app = Get-AppxPackage -Name 'Microsoft.PowerShell'; if ($app) { Join-Path $app.InstallLocation 'pwsh.exe' }"') do (
        set "PWSH_PATH=%%i"
    )
    if not "!PWSH_PATH!"=="" goto :found
) else (
    echo [ERROR] Для удаления необходим PowerShell 7.
    pause
    exit /b 1
)

echo [ERROR] Не удалось найти или установить PowerShell 7.
pause
exit /b 1

:found
echo [OK] PowerShell 7 найден: !PWSH_PATH!
echo [INFO] Запуск !ACTION!...
echo.

"!PWSH_PATH!" -NoExit -ExecutionPolicy Bypass -File "%~dp0!ACTION!"

pause