﻿# Copyright (c) 2026 forXsis
# Licensed under the MIT License.

#Requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot

Write-Host "=== Termulin Installer ===" -ForegroundColor Cyan

$pwshPath = (Get-Process -Id $PID).Path
Write-Host "PowerShell 7 найден: $pwshPath" -ForegroundColor Green

Write-Host "`nВыберите тему для запуска по умолчанию:" -ForegroundColor Cyan
Write-Host "1. ❯ TRL Snow   (Снежный барс, графит)"
Write-Host "2. ❯ TRL Angel  (Статуя, мраморный монохром)"
Write-Host "3. ❯ TRL Sakura (Сакура, пепельно-розовый)"
Write-Host "4. Кастомная тема (создать свою)"
$choice = Read-Host "Введите номер (1-4)"

$defaultGuid = "{0ae5aee2-8fb8-45fa-bc2e-119a064c855a}"
$themeName = "TRL Snow"
$customThemeConfig = $null
$customImagePath = $null

if ($choice -eq "2") { $defaultGuid = "{1be5aee2-8fb8-45fa-bc2e-119a064c855a}"; $themeName = "TRL Angel" }
if ($choice -eq "3") { $defaultGuid = "{2ce5aee2-8fb8-45fa-bc2e-119a064c855a}"; $themeName = "TRL Sakura" }

if ($choice -eq "4") {
    Write-Host "`n=== Мастер кастомной темы ===" -ForegroundColor Magenta

    Write-Host "1. Путь к фоновому изображению (перетащите файл сюда или введите путь):"
    $imgInput = Read-Host
    $customImagePath = $imgInput.Trim('"').Trim("'")
    if (-not (Test-Path $customImagePath)) {
        Write-Host "Файл не найден. Будет использован фон рабочего стола." -ForegroundColor Yellow
        $customImagePath = "desktopWallpaper"
    }

    Write-Host "2. Название профиля (например, 'My Custom'):"
    $themeName = Read-Host
    if (-not $themeName) { $themeName = "TRL Custom" }
    $defaultGuid = "{9ce5aee2-8fb8-45fa-bc2e-119a064c855a}"

    Write-Host "3. HEX-цвет фона (например, #111111):"
    $bgColor = Read-Host
    if (-not $bgColor) { $bgColor = "#111111" }

    Write-Host "4. HEX-цвет основного текста (например, #EEEEEE):"
    $fgColor = Read-Host
    if (-not $fgColor) { $fgColor = "#EEEEEE" }

    Write-Host "5. HEX-цвет акцента (промт, кнопки, например, #88C0D0):"
    $accentColor = Read-Host
    if (-not $accentColor) { $accentColor = "#88C0D0" }

    Write-Host "`n6. Настройка промта. Доступные переменные: {time}, {folder}, {pwsh}"
    Write-Host "Текущий: ╭─[{time}]─[{folder}]─[{pwsh}]`n╰─❯"
    Write-Host "Оставьте пустым, чтобы использовать текущий, или введите свой шаблон (например, '{folder} >'):"
    $customPrompt = Read-Host
    if (-not $customPrompt) {
        $customPrompt = "╭─[{time}]─[{folder}]─[{pwsh}]`n╰─❯"
    }

    $customThemeConfig = @{
        bg = $bgColor
        fg = $fgColor
        accent = $accentColor
        prompt = $customPrompt
    }
}

Write-Host "Выбрана тема: $themeName" -ForegroundColor Green

$wtSettings = "$env:LOCALAPPDATA\Packages\Microsoft.WindowsTerminal_8wekyb3d8bbwe\LocalState\settings.json"

if (Test-Path $wtSettings) {
    $bak = "$wtSettings.bak-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
    Copy-Item $wtSettings $bak
    Write-Host "Бэкап Windows Terminal: $bak" -ForegroundColor DarkGray

    $wt = [System.IO.File]::ReadAllText($wtSettings, [System.Text.Encoding]::UTF8) | ConvertFrom-Json

    if ($wt.schemes) { $wt.schemes = @($wt.schemes | Where-Object { $_.name -notmatch '^TRL' }) }
    $guids = @("{0ae5aee2-8fb8-45fa-bc2e-119a064c855a}", "{1be5aee2-8fb8-45fa-bc2e-119a064c855a}", "{2ce5aee2-8fb8-45fa-bc2e-119a064c855a}", "{9ce5aee2-8fb8-45fa-bc2e-119a064c855a}")
    $wt.profiles.list = @($wt.profiles.list | Where-Object { $_.guid -notin $guids })

    $schemes = @(
        @{ 
            name="TRL-Snow"; background="#0F1115"; foreground="#E0E0E0"; cursorColor="#E0E0E0"; selectionBackground="#3A3D45"; 
            black="#1A1C23"; red="#A36A75"; green="#7A9A82"; yellow="#C6B388"; blue="#7C94AD"; purple="#9A829A"; cyan="#799A9D"; white="#D8DEE9"; 
            brightBlack="#4C566A"; brightRed="#C7848E"; brightGreen="#98BAA0"; brightYellow="#D8C79D"; brightBlue="#9EB3CC"; brightPurple="#B8A0B8"; brightCyan="#9ABDC0"; brightWhite="#FFFFFF" 
        },
        @{ 
            name="TRL-Angel"; background="#050505"; foreground="#F4F4F4"; cursorColor="#F4F4F4"; selectionBackground="#3B3B3B"; 
            black="#111111"; red="#8C8C8C"; green="#A8A8A8"; yellow="#C4C4C4"; blue="#B0B0B0"; purple="#999999"; cyan="#D4D4D4"; white="#FFFFFF"; 
            brightBlack="#444444"; brightRed="#B0B0B0"; brightGreen="#D4D4D4"; brightYellow="#E8E8E8"; brightBlue="#C4C4C4"; brightPurple="#B0B0B0"; brightCyan="#F4F4F4"; brightWhite="#FFFFFF" 
        },
        @{ 
            name="TRL-Sakura"; background="#0A080A"; foreground="#FDF0F5"; cursorColor="#FDF0F5"; selectionBackground="#4A3B42"; 
            black="#1A1215"; red="#F2D5DE"; green="#D1B2BD"; yellow="#E6D0D7"; blue="#AFA2A6"; purple="#DDBCC7"; cyan="#EED6DE"; white="#FDF0F5"; 
            brightBlack="#4A3B42"; brightRed="#FDE8EF"; brightGreen="#E6C3CF"; brightYellow="#FDE8EF"; brightBlue="#C7B1B8"; brightPurple="#F2D5DE"; brightCyan="#FFF0F5"; brightWhite="#FFFFFF" 
        }
    )

    if ($customThemeConfig) {
        $schemes += @{ 
            name="TRL-Custom"; background=$customThemeConfig.bg; foreground=$customThemeConfig.fg; cursorColor=$customThemeConfig.accent; selectionBackground="#444444"; 
            black="#222222"; red="#A36A75"; green="#7A9A82"; yellow="#C6B388"; blue="#7C94AD"; purple="#9A829A"; cyan=$customThemeConfig.accent; white=$customThemeConfig.fg; 
            brightBlack="#555555"; brightRed="#C7848E"; brightGreen="#98BAA0"; brightYellow="#D8C79D"; brightBlue="#9EB3CC"; brightPurple="#B8A0B8"; brightCyan=$customThemeConfig.accent; brightWhite="#FFFFFF" 
        }
    }

    $wt.schemes = @($wt.schemes) + $schemes

    $baseProf = $wt.profiles.list | Where-Object { $_.guid -eq "{574e775e-4f2a-5b96-ac1e-a2962a402336}" } | Select-Object -First 1
    if (-not $baseProf) { $baseProf = $wt.profiles.list[0] }

    $newProfiles = @(
        [PSCustomObject]@{
            guid = $guids[0]; name = "❯ TRL Snow"; commandline = "`"$pwshPath`""
            icon = $baseProf.icon; colorScheme = "TRL-Snow"; font = [PSCustomObject]@{ face = "Liberation Mono"; weight = "bold" }
            backgroundImage = "$root\background\SnowLight.png"; backgroundImageOpacity = 0.5
            opacity = 50; useAcrylic = $true; padding = "12, 12, 12, 12"; startingDirectory = "%USERPROFILE%"
            suppressApplicationTitle = $true; tabColor = "#363636"
        },
        [PSCustomObject]@{
            guid = $guids[1]; name = "❯ TRL Angel"; commandline = "`"$pwshPath`""
            icon = $baseProf.icon; colorScheme = "TRL-Angel"; font = [PSCustomObject]@{ face = "Liberation Mono"; weight = "bold" }
            backgroundImage = "$root\background\BlackAngel.png"; backgroundImageOpacity = 0.6
            opacity = 60; useAcrylic = $true; padding = "12, 12, 12, 12"; startingDirectory = "%USERPROFILE%"
            suppressApplicationTitle = $true; tabColor = "#1A1A1A"
        },
        [PSCustomObject]@{
            guid = $guids[2]; name = "❯ TRL Sakura"; commandline = "`"$pwshPath`""
            icon = $baseProf.icon; colorScheme = "TRL-Sakura"; font = [PSCustomObject]@{ face = "Liberation Mono"; weight = "bold" }
            backgroundImage = "$root\background\WhiteSakura.png"; backgroundImageOpacity = 0.7
            opacity = 60; useAcrylic = $true; padding = "12, 12, 12, 12"; startingDirectory = "%USERPROFILE%"
            suppressApplicationTitle = $true; tabColor = "#2A2A2A"
        }
    )

    if ($customThemeConfig) {
        $newProfiles += [PSCustomObject]@{
            guid = $guids[3]; name = "❯ $themeName"; commandline = "`"$pwshPath`""
            icon = $baseProf.icon; colorScheme = "TRL-Custom"; font = [PSCustomObject]@{ face = "Liberation Mono"; weight = "bold" }
            backgroundImage = $customImagePath; backgroundImageOpacity = 0.5
            opacity = 60; useAcrylic = $true; padding = "12, 12, 12, 12"; startingDirectory = "%USERPROFILE%"
            suppressApplicationTitle = $true; tabColor = $customThemeConfig.bg
        }
    }

    $wt.profiles.list = @($wt.profiles.list) + $newProfiles
    $wt | Add-Member -MemberType NoteProperty -Name defaultProfile -Value $defaultGuid -Force

    [System.IO.File]::WriteAllText($wtSettings, ($wt | ConvertTo-Json -Depth 20), [System.Text.UTF8Encoding]::new($false))
    Write-Host "Windows PowerShell настроен" -ForegroundColor Green
}

$ProfilePath = $PROFILE
if (Test-Path $ProfilePath) {
    $bak = "$ProfilePath.bak-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
    Copy-Item $ProfilePath $bak
} else {
    New-Item -ItemType Directory -Path (Split-Path $ProfilePath -Parent) -Force | Out-Null
    New-Item -ItemType File -Path $ProfilePath -Force | Out-Null
}

if ($customThemeConfig) {
    $themeJsonPath = Join-Path $root "theme.json"
    $theme = [System.IO.File]::ReadAllText($themeJsonPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
    $theme.prompt.template = $customThemeConfig.prompt
    [System.IO.File]::WriteAllText($themeJsonPath, ($theme | ConvertTo-Json -Depth 10), [System.Text.UTF8Encoding]::new($false))
}

$block = @"

# >>> TRL-Theme >>>
`$PSDefaultParameterValues['Out-Default:OutVariable'] = `$null
Import-Module '$root\Theme.psd1' -Force
function global:prompt { & (Get-Module Theme) { prompt } }
Show-Banner
# <<< TRL-Theme <<<
"@

$content = [System.IO.File]::ReadAllText($ProfilePath, [System.Text.Encoding]::UTF8)
if ($content -match '# >>> TRL-Theme >>>') {
    $content = [regex]::Replace($content, '(?s)# >>> TRL-Theme >>>.*?# <<< TRL-Theme <<<\r?\n?', $block.Trim() + "`r`n")
} else {
    $content = $content.TrimEnd() + "`r`n" + $block
}
[System.IO.File]::WriteAllText($ProfilePath, $content, [System.Text.UTF8Encoding]::new($false))

$desktop = [Environment]::GetFolderPath("Desktop")
$launcherPath = Join-Path $root "Launch.bat"

$batContent = @"
@echo off
title Termulin Launcher
wt.exe -p "❯ $themeName"
"@
[System.IO.File]::WriteAllText($launcherPath, $batContent, [System.Text.Encoding]::Default)

$wshell = New-Object -ComObject WScript.Shell

$shortcut1 = $wshell.CreateShortcut((Join-Path $desktop "$themeName.lnk"))
$shortcut1.TargetPath = "wt.exe"
$shortcut1.Arguments = "-p `"❯ $themeName`""
$shortcut1.Save()

Write-Host "Ярлыки и лаунчер созданы!" -ForegroundColor Cyan
Write-Host "Установка завершена! Тема по умолчанию: $themeName" -ForegroundColor Green