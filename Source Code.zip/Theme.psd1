# Copyright (c) 2026 forXsis
# Licensed under the MIT License.

@{
    RootModule        = 'Theme.psm1'
    ModuleVersion     = '1.1.0'
    GUID              = 'a3b8c1d2-4e5f-4a6b-9c7d-1e2f3a4b5c6d'
    Author            = 'forXsis'
    Description       = 'Console theme: banner, prompt, colors from theme.json'
    PowerShellVersion = '7.0'
    FunctionsToExport = @('Show-Banner', 'prompt', 'Get-Theme', 'Update-Theme', 'Set-ConsoleTitle')
    CmdletsToExport   = @()
    VariablesToExport = @()
    AliasesToExport   = @()
}