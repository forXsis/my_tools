# Copyright (c) 2026 forXsis
# Licensed under the MIT License.

#Requires -Version 7.0
<#
.SYNOPSIS
#>
[CmdletBinding()]
param()

$Host.UI.RawUI.WindowTitle = "Booting DTerm..."
Clear-Host

$esc = [char]27
$reset = "$esc[0m"
$green = "$esc[92m"
$gray = "$esc[90m"
$white = "$esc[97m"
$cyan = "$esc[96m"
$clear = "$esc[2J$esc[3J$esc[H"

function Sleep-Ms($ms) { Start-Sleep -Milliseconds $ms }
function Get-RandomStr($len) { -join ((65..90) + (97..122) + (48..57) | Get-Random -Count $len | % {[char]$_}) }
$s = _Get-StaticContext
$logs = @()
$logs += "[ ${green}OK${reset} ] Initializing DTerm Core v1.1.0..."
$logs += "[ ${green}OK${reset} ] LX subsystem emulation started..."
$logs += "[ ${gray}INFO${reset} ] CPU: " + $s.cpu
$logs += "[ ${gray}INFO${reset} ] RAM: " + $s.ram
$logs += "[ ${green}OK${reset} ] Mounting /dev/sda1 on / type ntfs3 (rw,relatime)"
$logs += "[ ${green}OK${reset} ] Starting udev daemon..."
$logs += "[ ${gray}INFO${reset} ] device: /dev/tty0 -> allocated console"
$logs += "[ ${green}OK${reset} ] Setting up hostname: " + $s.hostname
$logs += "[ ${gray}INFO${reset} ] random: crng init done"
$logs += "[ ${green}OK${reset} ] Reached target Local File Systems."
$logs += "[ ${green}OK${reset} ] Reached target Network."
$logs += "[ ${gray}INFO${reset} ] eth0: link up, 1000 Mbps, full duplex"
$logs += "[ ${green}OK${reset} ] Started Network Manager."
$logs += "[ ${gray}INFO${reset} ] dnsmasq: started, version 2.89 cachesize 1000"
$logs += "[ ${green}OK${reset} ] Started D-Bus System Message Bus."
$logs += "[ ${gray}INFO${reset} ] Started Session 1 of user Admin."
$logs += "[ ${green}OK${reset} ] Created slice User Slice of UID 1000."
$logs += "[ ${gray}INFO${reset} ] systemd-logind: New session 1 of user Admin."
$logs += "[ ${green}OK${reset} ] Started Authorization Manager."
$logs += "[ ${gray}INFO${reset} ] Loading Windows Terminal profiles..."
$logs += "[ ${green}OK${reset} ] Injected ANSI color scheme: DTerm"
$logs += "[ ${gray}INFO${reset} ] Applying font: Liberation Mono (extra-bold)"
$logs += "[ ${green}OK${reset} ] Loaded backgroundImage: desktopWallpaper"
$logs += "[ ${green}OK${reset} ] Set acrylic opacity to 50%"
$logs += "[ ${gray}INFO${reset} ] Starting PowerShell 7 environment..."
$logs += "[ ${green}OK${reset} ] Mounted module: Theme.psm1"
$logs += "[ ${gray}INFO${reset} ] Loading cached system context..."
$logs += "[ ${green}OK${reset} ] Starting custom prompt renderer..."
$logs += "[ ${gray}INFO${reset} ] Checking for updates... none found"
$logs += "[ ${green}OK${reset} ] Reached target Multi-User System."
$logs += "[ ${gray}INFO${reset} ] Startup finished in 1.402s (kernel) + 2.115s (userspace)"
$logs += "[ ${green}OK${reset} ] System is ready. Welcome back, Admin."

foreach ($log in $logs) {
    $time = (Get-Date).ToString("HH:mm:ss.fff")
    
    Write-Host "$gray[$time]$reset $white$log$reset"
    
    $roll = Get-Random -Minimum 1 -Maximum 100
    if ($roll -le 15) {
        Sleep-Ms (Get-Random -Minimum 300 -Maximum 350)
    } elseif ($roll -le 40) {
        Sleep-Ms (Get-Random -Minimum 100 -Maximum 150)
    } elseif ($roll -le 80) {
        Sleep-Ms (Get-Random -Minimum 20 -Maximum 70)
    } else {
        Sleep-Ms 5
    }
}

Sleep-Ms 400

Write-Host $clear

$asciiArt = @"
$cyan
      ██████╗ ████████╗███████╗██████╗ ███╗   ███╗
      ██╔══██╗╚══██╔══╝██╔════╝██╔══██╗████╗ ████║
      ██║  ██║   ██║   █████╗  ██████╔╝██╔████╔██║
      ██║  ██║   ██║   ██╔══╝  ██╔══██╗██║╚██╔╝██║
      ██████╔╝   ██║   ███████╗██║  ██║██║ ╚═╝ ██║
      ╚═════╝    ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝
$reset
"@
Write-Host $asciiArt
Write-Host "${reset}             >>> Dark Edition <<<$reset"
Sleep-Ms 400
Write-Host "${reset}        >>> Developed by: FORXSIS <<<$reset`n"

Sleep-Ms 1200

Write-Host $clear

# setup shell + profile
& pwsh -NoExit