# Copyright (c) 2026 forXsis
# Licensed under the MIT License.

#Requires -Version 7.0
Set-StrictMode -Version Latest

$script:Esc = [char]27
$script:AnsiColors = @{
    black='30'; darkred='31'; darkgreen='32'; darkyellow='33'
    darkblue='34'; darkmagenta='35'; darkcyan='36'; gray='37'
    darkgray='90'; red='91'; green='92'; yellow='93'
    blue='94'; magenta='95'; cyan='96'; white='97'
}
$script:Reset = "$($script:Esc)[0m"

function _Color([string]$name) {
    if ($script:AnsiColors.ContainsKey($name)) { return "$($script:Esc)[$($script:AnsiColors[$name])m" }
    return ''
}

$script:ThemePath = Join-Path $PSScriptRoot 'theme.json'
$script:CachePath = Join-Path $PSScriptRoot 'theme.cache.json'
$script:Theme     = $null
$script:StaticCtx = $null

function Get-Theme {
    if (-not $script:Theme) { Update-Theme | Out-Null }
    return $script:Theme
}

function Update-Theme {
    if (-not (Test-Path $script:ThemePath)) { throw "theme.json не найден" }
    $raw = [System.IO.File]::ReadAllText($script:ThemePath, [System.Text.Encoding]::UTF8)
    $script:Theme = $raw | ConvertFrom-Json
    $script:StaticCtx = $null
    return $script:Theme
}

function _Get-StaticContext {
    if ($script:StaticCtx) { return $script:StaticCtx }
    if (Test-Path $script:CachePath) {
        try {
            $cache = [System.IO.File]::ReadAllText($script:CachePath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
            $script:StaticCtx = @{ os=$cache.os; hostname=$env:COMPUTERNAME; username=$env:USERNAME; cpu=$cache.cpu; ram=$cache.ram }
            return $script:StaticCtx
        } catch {}
    }
    $os = try { (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).Caption } catch { $env:OS }
    $cpu = try { (Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1).Name.Trim() } catch { 'n/a' }
    $ramBytes = try { (Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).TotalPhysicalMemory } catch { 0 }
    $ram = if ($ramBytes) { '{0:N1} GB' -f ($ramBytes / 1GB) } else { 'n/a' }

    $script:StaticCtx = @{ os=$os; hostname=$env:COMPUTERNAME; username=$env:USERNAME; cpu=$cpu; ram=$ram }
    $script:StaticCtx | ConvertTo-Json | Set-Content $script:CachePath -Encoding UTF8
    return $script:StaticCtx
}

function _Get-Context {
    $s = _Get-StaticContext
    $cwd = (Get-Location).Path
    $folder = Split-Path $cwd -Leaf
    if ($cwd -eq $env:USERPROFILE) { $folder = "~" }
    [ordered]@{
        date     = (Get-Date).ToString('yyyy-MM-dd')
        time     = (Get-Date).ToString('HH:mm:ss')
        os       = $s.os
        hostname = $s.hostname
        username = $s.username
        cpu      = $s.cpu
        ram      = $s.ram
        cwd      = $cwd
        folder   = $folder
        pwsh     = "v$($PSVersionTable.PSVersion.Major)"
    }
}

function _Expand-Template([string]$template, [hashtable]$ctx) {
    [regex]::Replace($template, '\{(\w+)\}', {
        param($m)
        if ($ctx.Contains($m.Groups[1].Value)) { return [string]$ctx[$m.Groups[1].Value] }
        return $m.Value
    })
}

function _DisplayWidth([string]$s) {
    $w = 0
    foreach ($ch in $s.ToCharArray()) {
        $code = [int]$ch
        if ($code -ge 0x1F300 -and $code -le 0x1FAFF) { $w += 2 }
        else { $w += 1 }
    }
    return $w
}

function _PadRight([string]$s, [int]$width) {
    $w = _DisplayWidth $s
    if ($w -ge $width) { return $s }
    return $s + (' ' * ($width - $w))
}

function Show-Banner {
    $t = Get-Theme
    if (-not $t.banner.enabled) { return }
    $ctx   = _Get-Context
    $box   = $t.box
    $chars = $box.chars
    $inner = $box.width - 2
    $cBorder = _Color $t.colors.border
    $cAccent = _Color $t.colors.accent
    $cValue  = _Color $t.colors.value
    $cMuted  = _Color $t.colors.muted
    $r = $script:Reset

    $title = $t.banner.title
    $titleW = _DisplayWidth $title
    $leftLen = [math]::Floor(($inner - $titleW) / 2)
    $rightLen = $inner - $titleW - $leftLen
    Write-Host ($cBorder + $chars.tl + ($chars.h * $leftLen) + $r + $cAccent + $title + $r + $cBorder + ($chars.h * $rightLen) + $chars.tr + $r)

    foreach ($f in $t.banner.fields) {
        $value = _Expand-Template $f.template $ctx
        $label = "$($f.label):"
        $line  = $cMuted + $chars.v + $r + ' ' + $cAccent + (_PadRight $label 12) + $r + $cValue + $value + $r
        $used = 1 + 12 + 1 + (_DisplayWidth $value)
        $pad  = $inner - $used
        if ($pad -lt 0) { $pad = 0 }
        Write-Host ($line + (' ' * $pad) + ' ' + $cBorder + $chars.v + $r)
    }
    Write-Host ($cBorder + $chars.bl + ($chars.h * $inner) + $chars.br + $r)
}

function prompt {
    $ctx = _Get-Context
    $cBorder = _Color "darkgray"
    $cTime   = _Color "gray"
    $cCwd    = _Color "darkyellow"
    $cSym    = _Color "darkcyan"
    $r       = $script:Reset

    $line1 = "$cBorder╭─$r$cTime[$($ctx.time)]$r$cBorder─$r$cCwd[$($ctx.folder)]$r$cBorder"
    $line2 = "$cBorder╰─$r$cSym❯$r "
    
    return "$line1`n$line2"
}

Export-ModuleMember -Function Show-Banner, prompt, Get-Theme, Update-Theme