# Copyright (c) 2026 forXsis
# Licensed under the MIT License.

#Requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot

Write-Host "=== Termulin Uninstaller ===" -ForegroundColor Cyan

$wtSettings = "$env:LOCALAPPDATA\Packages\Microsoft.WindowsTerminal_8wekyb3d8bbwe\LocalState\settings.json"

if (Test-Path $wtSettings) {
    $bak = "$wtSettings.bak-uninstall-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
    Copy-Item $wtSettings $bak
    Write-Host "Бэкап Windows Terminal: $bak" -ForegroundColor DarkGray

    $wt = [System.IO.File]::ReadAllText($wtSettings, [System.Text.Encoding]::UTF8) | ConvertFrom-Json

    if ($wt.schemes) {
        $wt.schemes = @($wt.schemes | Where-Object { $_.name -notmatch '^LDTerm' })
    }

    $guids = @(
        "{0ae5aee2-8fb8-45fa-bc2e-119a064c855a}", # Snow
        "{1be5aee2-8fb8-45fa-bc2e-119a064c855a}", # Angel
        "{2ce5aee2-8fb8-45fa-bc2e-119a064c855a}", # Sakura
        "{9ce5aee2-8fb8-45fa-bc2e-119a064c855a}"  # Custom
    )
    $wt.profiles.list = @($wt.profiles.list | Where-Object { $_.guid -notin $guids })

    if ($wt.defaultProfile -in $guids) {
        $wt.defaultProfile = "{574e775e-4f2a-5b96-ac1e-a2962a402336}" # Стандартный PowerShell 7
    }

    [System.IO.File]::WriteAllText($wtSettings, ($wt | ConvertTo-Json -Depth 20), [System.Text.UTF8Encoding]::new($false))
    Write-Host "Windows Terminal очищен." -ForegroundColor Green
}

$profilesToClean = @(
    $PROFILE, 
    "$env:USERPROFILE\Documents\WindowsPowerShell\Microsoft.PowerShell_profile.ps1"
)

foreach ($ProfilePath in $profilesToClean) {
    if ($ProfilePath -and (Test-Path $ProfilePath)) {
        $content = [System.IO.File]::ReadAllText($ProfilePath, [System.Text.Encoding]::UTF8)
        $newContent = [regex]::Replace($content, '(?s)# >>> TRL-Theme >>>.*?# <<< TRL-Theme <<<\r?\n?', "`r`n")
        
        if ($newContent -ne $content) {
            [System.IO.File]::WriteAllText($ProfilePath, $newContent, [System.Text.UTF8Encoding]::new($false))
            Write-Host "Очищен профиль: $ProfilePath" -ForegroundColor Green
        }
    }
}

$desktop = [Environment]::GetFolderPath("Desktop")
$shortcuts = @(
    "TRL Snow.lnk",
    "TRL Angel.lnk",
    "TRL Sakura.lnk",
    "TRL Custom.lnk",
    "TRL Launcher.lnk",
    "TRL Boot.lnk"
)

foreach ($sc in $shortcuts) {
    $scPath = Join-Path $desktop $sc
    if (Test-Path $scPath) {
        Remove-Item $scPath -Force
        Write-Host "Удален ярлык: $sc" -ForegroundColor Green
    }
}

$launcherPath = Join-Path $root "Launch.bat"
if (Test-Path $launcherPath) {
    Remove-Item $launcherPath -Force
    Write-Host "Удален Launch.bat" -ForegroundColor Green
}

Write-Host "`nУдаление завершено! Перезапустите Windows Terminal." -ForegroundColor Cyan